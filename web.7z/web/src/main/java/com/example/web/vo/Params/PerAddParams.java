package com.example.web.vo.Params;

import lombok.Data;

@Data
public class PerAddParams {

    private String limitName;
    private String description;
    private String url;
}
