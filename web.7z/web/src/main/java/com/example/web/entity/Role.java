package com.example.web.entity;

import lombok.Data;

@Data
public class Role {
    private Integer id;
    private String roleName;
    private String descriptionR;
}
