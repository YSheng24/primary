package com.example.web.vo.Params;

import lombok.Data;

@Data
public class LoginParams {
    private String loginName;
    private String password;
}
