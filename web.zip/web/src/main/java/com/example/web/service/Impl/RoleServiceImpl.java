package com.example.web.service.Impl;

import com.example.web.entity.Role;
import com.example.web.mapper.RMapper;
import com.example.web.service.RoleService;
import com.example.web.vo.ErrorCode;
import com.example.web.vo.Params.*;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RMapper roleDao;

    //查
    @Override
    public List<Role> getRoleAll(){
        return roleDao.getAll();
    }

    //增加
    @Override
    public Result addRole(RoleAddParams role){

        String roleName = role.getRoleName();
        String decriptionR = role.getDescriptionR();

        if (roleName == null || roleName.equals(" ")
                || roleName == "" || roleName.contains(" ")
                || decriptionR == null || decriptionR.equals(" ")
                || decriptionR == "" || decriptionR.contains(" ")) {
            return Result.fail(ErrorCode.PARAMS_ERROR.getCode(),ErrorCode.PARAMS_ERROR.getMsg());
        } else if (roleName.length() > 50) {
            return Result.fail(ErrorCode.ROLE_NAME_TOO_LONG.getCode(),ErrorCode.ROLE_NAME_TOO_LONG.getMsg());
        } else if(decriptionR.length() >100){
            return Result.fail(ErrorCode.ROLE_DESCRIPTION_TOO_LONG.getCode(),ErrorCode.ROLE_DESCRIPTION_TOO_LONG.getMsg());
        }
        else {
            roleDao.add(role);
            return Result.success(ErrorCode.ADD_SUCCESSFUL.getCode(),ErrorCode.ADD_SUCCESSFUL.getMsg(),role);
        }
    }

    //修改
    @Override
    public Result updateRole(RoleUpdateParams updateParams){

        Integer id = updateParams.getId();
        String roleName = updateParams.getRoleName();
        String des = updateParams.getDescriptionR();

        if (roleName == null || roleName.equals(" ")
                || roleName == "" || roleName.contains(" ")
                || des == null || des.equals(" ")
                || des == "" || des.contains(" ")) {
            return Result.fail(ErrorCode.PARAMS_ERROR.getCode(),ErrorCode.PARAMS_ERROR.getMsg());
        } else if (roleName.length() > 50) {
            return Result.fail(ErrorCode.ROLE_NAME_TOO_LONG.getCode(),ErrorCode.ROLE_NAME_TOO_LONG.getMsg());
        } else if(des.length() >100){
            return Result.fail(ErrorCode.ROLE_DESCRIPTION_TOO_LONG.getCode(),ErrorCode.ROLE_DESCRIPTION_TOO_LONG.getMsg());
        }else {
            roleDao.update(updateParams);
            return Result.success(ErrorCode.UPDATE_SUCCESSFUL.getCode(),ErrorCode.UPDATE_SUCCESSFUL.getMsg(),updateParams);
        }
    }
    //删除
    @Override
    public Result delRole(IdDelParams idDelParams){

        Integer id = idDelParams.getId();

        Role u = (Role) roleDao.getById(id);

        if(u == null){
            return Result.fail(ErrorCode.ROLE_NOT_EXIST.getCode(),ErrorCode.ROLE_NOT_EXIST.getMsg());
        }else{
            roleDao.del(idDelParams);
            return Result.success(ErrorCode.DEL_SUCCESSFUL.getCode(),ErrorCode.DEL_SUCCESSFUL.getMsg(), idDelParams);
        }
    }

}
