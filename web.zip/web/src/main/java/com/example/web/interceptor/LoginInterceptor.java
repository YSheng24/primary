package com.example.web.interceptor;


import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.web.util.JWTUtils;
import com.example.web.vo.ErrorCode;
import com.example.web.vo.Result;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import com.alibaba.fastjson.JSON;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component

public class LoginInterceptor implements HandlerInterceptor {


    private Logger log = LoggerFactory.getLogger(LoginInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        try {
            if (!(handler instanceof HandlerMethod)) {
                return true;
            }
            String token = request.getHeader("token");

            String requestURI = request.getRequestURI();

            if (token == null || token == "") {
                Result result = Result.fail(ErrorCode.NO_LOGIN.getCode(), ErrorCode.NO_LOGIN.getMsg());
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(result));
                return false;
            }

            DecodedJWT u = JWTUtils.getToken(token);
            if (u == null) {
                Result result = Result.fail(ErrorCode.NO_LOGIN.getCode(), ErrorCode.NO_LOGIN.getMsg());
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().print(JSON.toJSONString(result));
            }
            //是登录状态，放行
            return true;

        }catch (Exception e){
            Result result = Result.fail(ErrorCode.SESSION_TIME_OUT.getCode(),ErrorCode.SESSION_TIME_OUT.getMsg());
            response.setContentType("application/json;charset=utf-8");
            response.getWriter().print(JSON.toJSONString(result));
            return false;
        }
    }
}