package com.example.web.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PMapper<T> {
    //判断是否存在-name
    T getByName(String name);

    //判断是否存在-id
    T getById(Integer id);

    //查
    List<T> getAll();

    //增加
    int add(T t);

    //修改
    int update(T t);

    //删除
    int del(T t);
}
