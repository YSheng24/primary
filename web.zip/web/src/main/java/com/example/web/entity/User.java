package com.example.web.entity;


import lombok.Data;

@Data
public class User {
    private Integer id;
    private String loginName;
    private String password;
}
