package com.example.web.service;

import com.example.web.entity.User;
import com.example.web.vo.Params.LoginParams;
import com.example.web.vo.Result;

public interface LoginService {
    Result login(LoginParams loginParams);


}
