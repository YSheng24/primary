package com.example.web.service;

import com.example.web.entity.Role;
import com.example.web.vo.Params.RoleAddParams;
import com.example.web.vo.Params.IdDelParams;
import com.example.web.vo.Params.RoleUpdateParams;
import com.example.web.vo.Params.UserUpdateParams;
import com.example.web.vo.Result;
import org.springframework.stereotype.Service;

import java.util.List;


public interface RoleService {
    //查
    List<Role> getRoleAll();

    //增
    Result addRole(RoleAddParams role);

    //修改
    Result updateRole(RoleUpdateParams id);

    //删除
    Result delRole(IdDelParams id);
}
