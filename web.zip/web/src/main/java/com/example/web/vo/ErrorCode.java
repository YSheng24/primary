package com.example.web.vo;

public enum  ErrorCode {

    //参数
    PARAMS_ERROR(10001,"参数有误"),

    //增加
    ADD_SUCCESSFUL(10002,"注册成功！"),

    //更新
    UPDATE_SUCCESSFUL(10002,"更新成功！"),

    //删除
    DEL_SUCCESSFUL(10002,"删除成功！"),

    //用户--------------------------------------------------
    ACCOUNT_HAS_EXIST(10001,"用户已存在！"),
    ACCOUNT_PWD_NOT_NULL(10002,"用户名或密码不能为空或null或含有空格！"),
    ACCOUNT_TOO_LONG(10003,"请输入长度为100以内的用户名！"),
    PWD_LENGTH(10004,"请输入6位数密码！"),
    ACCOUNT_NOT_EXIST(10005,"用户不存在！"),

    //角色----------------------------------------------------
    ROLE_NAME_TOO_LONG(10002,"请输入长度为50以内的名字！"),
    ROLE_DESCRIPTION_TOO_LONG(10003,"请输入长度为100以内的描述信息！"),
    ROLE_NOT_EXIST(10004,"角色不存在！"),

    //权限----------------------------------------------------
    PER_HAS_EXIST(10002,"权限已存在！"),
    PER_NAME_TOO_LONG(10003,"请输入长度50以内的权限名！"),
    PER_DES_TOO_LONG(10004,"请输入长度100以内的描述！"),
    PER_URL_TOO_LONG(10005,"请输入长度100以内的URL"),
    PER_NOT_EXIST(10006,"权限不存在！"),


    //登录-----------------------------------------------------
    TOKEN_GET(10001,"登录成功！"),
    ACCOUNT_PWD_NOT_EXIST(10002,"用户名或密码不存在!"),
    NO_PERMISSION(10003,"无访问权限!"),
    SESSION_TIME_OUT(10004,"会话超时!"),
    NO_LOGIN(10005,"未登录!"),
    ;

    private int code;
    private String msg;

    ErrorCode(int code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
