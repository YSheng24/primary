package com.example.web.mapper;


import com.example.web.entity.User;
import com.example.web.vo.Params.LoginParams;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UMapper<T> {

    //判断是否存在-name
    T getByName(String name);

    //判断是否存在-id
    T getById(Integer id);

    //查
    List<T> getAll();

    //增加
    int add(T t);

    //修改
    int update(T t);

    //删除
    int del(T t);

    //登录
    User login(T t);

    //查询是否存在该用户名和密码
    T getByNameAndPwd(LoginParams loginParams);
}
