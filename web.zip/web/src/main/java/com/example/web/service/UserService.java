package com.example.web.service;

import com.example.web.entity.User;
import com.example.web.vo.Params.UserAddParams;
import com.example.web.vo.Params.IdDelParams;
import com.example.web.vo.Params.UserUpdateParams;
import com.example.web.vo.Result;

import java.util.List;

public interface UserService {

    //查
    List<User> getUserAll();

    //增
    Result addUser(UserAddParams user);

    //修改
    Result updateUser(UserUpdateParams id);

    //删除
    Result delUser(IdDelParams id);

}
