package com.example.web.vo.Params;

import lombok.Data;

@Data
public class UserAddParams {
    private String loginName;

    private String password;
}
