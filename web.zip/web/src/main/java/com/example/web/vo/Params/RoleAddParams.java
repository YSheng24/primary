package com.example.web.vo.Params;

import lombok.Data;

@Data
public class RoleAddParams {
    private String roleName;
    private String descriptionR;
}
