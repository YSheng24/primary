package com.example.web.vo.Params;

import lombok.Data;

@Data
public class IdDelParams {
    private Integer id;
}
