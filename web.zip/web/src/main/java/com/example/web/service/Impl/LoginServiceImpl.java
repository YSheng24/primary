package com.example.web.service.Impl;

import com.example.web.entity.User;
import com.example.web.mapper.UMapper;
import com.example.web.service.LoginService;
import com.example.web.util.JWTUtils;
import com.example.web.util.MD5Util;
import com.example.web.vo.ErrorCode;
import com.example.web.vo.Params.LoginParams;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UMapper loginDao;

    @Override
    @Transactional(propagation = Propagation.SUPPORTS)
    public Result login (LoginParams loginParams) {

        loginParams.setPassword(MD5Util.MD5Encode(loginParams.getPassword(),"UTF-8"));

        User userDB = (User) loginDao.getByNameAndPwd(loginParams);

        if(userDB == null){
            return Result.fail(ErrorCode.ACCOUNT_PWD_NOT_EXIST.getCode(),ErrorCode.ACCOUNT_PWD_NOT_EXIST.getMsg());
        }
        else {
            loginDao.login(loginParams);
            Map<String, String> map = new HashMap<>();//用来存放payload
            map.put("id",userDB.getId().toString());
            map.put("loginName", userDB.getLoginName());
            String token = JWTUtils.getToken(map);
            return Result.success(ErrorCode.TOKEN_GET.getCode(),ErrorCode.TOKEN_GET.getMsg(), token);
        }
    }
}
