package com.example.web.service.Impl;

import com.example.web.entity.User;
import com.example.web.mapper.UMapper;
import com.example.web.service.UserService;
import com.example.web.util.MD5Util;
import com.example.web.vo.ErrorCode;
import com.example.web.vo.Params.UserAddParams;
import com.example.web.vo.Params.IdDelParams;
import com.example.web.vo.Params.UserUpdateParams;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UMapper userDao;

    //查
    @Override
    public List<User> getUserAll(){
        return userDao.getAll();
    }

    //增加
    @Override
    public Result addUser(UserAddParams user){

        String loginName = user.getLoginName();
        String password = user.getPassword();

        User u = (User) userDao.getByName(loginName);
        if(u != null){
            return Result.fail(ErrorCode.ACCOUNT_HAS_EXIST.getCode(),ErrorCode.ACCOUNT_HAS_EXIST.getMsg());
        } else if (loginName == null || loginName.equals(" ")
                || loginName == "" || loginName.contains(" ")
                || password == null || password.equals(" ")
                || password == "" || password.contains(" ")) {
            return Result.fail(ErrorCode.ACCOUNT_PWD_NOT_NULL.getCode(),ErrorCode.ACCOUNT_PWD_NOT_NULL.getMsg());
        } else if (loginName.length() > 100) {
            return Result.fail(ErrorCode.ACCOUNT_TOO_LONG.getCode(),ErrorCode.ACCOUNT_TOO_LONG.getMsg());
        } else if(password.length() != 6){
            return Result.fail(ErrorCode.PWD_LENGTH.getCode(),ErrorCode.PWD_LENGTH.getMsg());
        }
        else {
            user.setPassword(MD5Util.MD5Encode(password,"UTF-8"));
            userDao.add(user);
            return Result.success(ErrorCode.ADD_SUCCESSFUL.getCode(),ErrorCode.ADD_SUCCESSFUL.getMsg(),user);
        }
    }

    //修改
    @Override
    public Result updateUser(UserUpdateParams updateParams){

        Integer id = updateParams.getId();
        String loginName = updateParams.getLoginName();
        String password = updateParams.getPassword();

        User uid = (User) userDao.getById(id);
        User uname = (User) userDao.getByName(loginName);

        if(uid == null){
            return Result.fail(ErrorCode.ACCOUNT_NOT_EXIST.getCode(),ErrorCode.ACCOUNT_NOT_EXIST.getMsg());
        }
        if(uname != null){
            return Result.fail(ErrorCode.ACCOUNT_HAS_EXIST.getCode(),ErrorCode.ACCOUNT_HAS_EXIST.getMsg());
        }else if (loginName == null || loginName.equals(" ")
                || loginName == "" || loginName.contains(" ")
                || password == null || password.equals(" ")
                || password == "" || password.contains(" ")) {
            return Result.fail(ErrorCode.ACCOUNT_PWD_NOT_NULL.getCode(),ErrorCode.ACCOUNT_PWD_NOT_NULL.getMsg());
        } else if (loginName.length() > 100) {
            return Result.fail(ErrorCode.ACCOUNT_TOO_LONG.getCode(),ErrorCode.ACCOUNT_TOO_LONG.getMsg());
        } else if(password.length() != 6){
            return Result.fail(ErrorCode.PWD_LENGTH.getCode(),ErrorCode.PWD_LENGTH.getMsg());
        }else {
            userDao.update(updateParams);
            return Result.success(ErrorCode.UPDATE_SUCCESSFUL.getCode(),ErrorCode.UPDATE_SUCCESSFUL.getMsg(),updateParams);
        }
    }

    //删除
    @Override
    public Result delUser(IdDelParams idDelParams){

        Integer id = idDelParams.getId();

        User u = (User) userDao.getById(id);

        if(u == null){
            return Result.fail(ErrorCode.ACCOUNT_NOT_EXIST.getCode(),ErrorCode.ACCOUNT_NOT_EXIST.getMsg());
        }else{
            userDao.del(idDelParams);
            return Result.success(ErrorCode.DEL_SUCCESSFUL.getCode(),ErrorCode.DEL_SUCCESSFUL.getMsg(), idDelParams);
        }
    }
}
