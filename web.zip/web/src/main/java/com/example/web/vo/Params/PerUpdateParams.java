package com.example.web.vo.Params;

import lombok.Data;

@Data
public class PerUpdateParams {
    private Integer id;
    private String limitName;
    private String description;
    private String url;
}
