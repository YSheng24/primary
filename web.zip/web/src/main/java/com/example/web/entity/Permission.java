package com.example.web.entity;

import lombok.Data;

@Data
public class Permission {
    private Integer id;
    private String limitName;
    private String description;
    private String url;
}
