package com.example.web.service.Impl;

import com.example.web.entity.Permission;
import com.example.web.entity.User;
import com.example.web.mapper.PMapper;
import com.example.web.service.PermissionService;
import com.example.web.util.MD5Util;
import com.example.web.vo.ErrorCode;
import com.example.web.vo.Params.*;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PMapper perDao;

    //查
    @Override
    public List<Permission> getPerAll(){
        return perDao.getAll();
    }

    //增加
    @Override
    public Result addPer(PerAddParams per){

        String perName = per.getLimitName();
        String des = per.getDescription();
        String url = per.getUrl();

        Permission u = (Permission) perDao.getByName(perName);
        if(u != null){
            return Result.fail(ErrorCode.PER_HAS_EXIST.getCode(),ErrorCode.PER_HAS_EXIST.getMsg());
        } else if (perName == null || perName.equals(" ")
                || perName == "" || perName.contains(" ")
                || des == null || des.equals(" ")
                || des == "" || des.contains(" ")
                || url == null || url.equals(" ")
                || url == "" || url.contains(" ")) {
            return Result.fail(ErrorCode.PARAMS_ERROR.getCode(),ErrorCode.PARAMS_ERROR.getMsg());
        } else if (perName.length() > 50) {
            return Result.fail(ErrorCode.PER_NAME_TOO_LONG.getCode(),ErrorCode.PER_NAME_TOO_LONG.getMsg());
        } else if(des.length() >100){
            return Result.fail(ErrorCode.PER_DES_TOO_LONG.getCode(),ErrorCode.PER_DES_TOO_LONG.getMsg());
        } else if (url.length() >100) {
            return Result.fail(ErrorCode.PER_URL_TOO_LONG.getCode(), ErrorCode.PER_URL_TOO_LONG.getMsg());
        } else {
            perDao.add(per);
            return Result.success(ErrorCode.ADD_SUCCESSFUL.getCode(),ErrorCode.ADD_SUCCESSFUL.getMsg(),per);
        }
    }

    //修改
    @Override
    public Result updatePer(PerUpdateParams updateParams){

        Integer id = updateParams.getId();
        String perName = updateParams.getLimitName();
        String des = updateParams.getDescription();
        String url = updateParams.getUrl();

        Permission uid = (Permission) perDao.getById(id);
        Permission uname = (Permission) perDao.getByName(perName);

        if(uid == null){
            return Result.fail(ErrorCode.PER_NOT_EXIST.getCode(),ErrorCode.PER_NOT_EXIST.getMsg());
        }
        if(uname != null){
            return Result.fail(ErrorCode.PER_HAS_EXIST.getCode(),ErrorCode.PER_HAS_EXIST.getMsg());
        } else if (perName == null || perName.equals(" ")
                || perName == "" || perName.contains(" ")
                || des == null || des.equals(" ")
                || des == "" || des.contains(" ")
                || url == null || url.equals(" ")
                || url == "" || url.contains(" ")) {
            return Result.fail(ErrorCode.PARAMS_ERROR.getCode(),ErrorCode.PARAMS_ERROR.getMsg());
        } else if (perName.length() > 50) {
            return Result.fail(ErrorCode.PER_NAME_TOO_LONG.getCode(),ErrorCode.PER_NAME_TOO_LONG.getMsg());
        } else if(des.length() >100){
            return Result.fail(ErrorCode.PER_DES_TOO_LONG.getCode(),ErrorCode.PER_DES_TOO_LONG.getMsg());
        } else if (url.length() >100) {
            return Result.fail(ErrorCode.PER_URL_TOO_LONG.getCode(), ErrorCode.PER_URL_TOO_LONG.getMsg());
    }else {
            perDao.update(updateParams);
            return Result.success(ErrorCode.UPDATE_SUCCESSFUL.getCode(),ErrorCode.UPDATE_SUCCESSFUL.getMsg(),updateParams);
        }
    }

    //删除
    @Override
    public Result delPer(IdDelParams idDelParams){

        Integer id = idDelParams.getId();

        Permission u = (Permission) perDao.getById(id);

        if(u == null){
            return Result.fail(ErrorCode.PER_NOT_EXIST.getCode(),ErrorCode.PER_NOT_EXIST.getMsg());
        }else{
            perDao.del(idDelParams);
            return Result.success(ErrorCode.DEL_SUCCESSFUL.getCode(),ErrorCode.DEL_SUCCESSFUL.getMsg(), idDelParams);
        }
    }

}
