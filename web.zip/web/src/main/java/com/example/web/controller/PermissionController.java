package com.example.web.controller;

import com.example.web.entity.Permission;
import com.example.web.service.PermissionService;
import com.example.web.vo.Params.*;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/permission")
public class PermissionController {
    @Autowired
    private PermissionService permissionService;

    //查
    @GetMapping("/getPerAll")
    public List<Permission> getPerAll(){
        List<Permission> all = permissionService.getPerAll();
        return all;
    }
    //增
    @PostMapping("/addPer")
    public Result addPer(@RequestBody PerAddParams per){
        return permissionService.addPer(per);
    }
    //修改
    @PutMapping("/updatePer")
    public Result updatePer(@RequestBody PerUpdateParams updateParams){
        return permissionService.updatePer(updateParams);
    }
    //删除
    @DeleteMapping("/delPer")
    public Result delPer(@RequestBody IdDelParams idDelParams){
        return permissionService.delPer(idDelParams);
    }

}
