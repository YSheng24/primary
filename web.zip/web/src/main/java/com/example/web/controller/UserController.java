package com.example.web.controller;

import com.example.web.entity.User;
import com.example.web.service.UserService;
import com.example.web.vo.Params.UserAddParams;
import com.example.web.vo.Params.IdDelParams;
import com.example.web.vo.Params.UserUpdateParams;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    //查
    @GetMapping("/getUserAll")
    public  List<User> getUserAll(){
        List<User> all = userService.getUserAll();
        return all;
    }
    //增
    @PostMapping("/addUser")
    public Result addUser(@RequestBody UserAddParams user){
        return userService.addUser(user);
    }
    //修改
    @PutMapping("/updateUser")
    public Result updateUser(@RequestBody UserUpdateParams updateParams){
        return userService.updateUser(updateParams);
    }
    //删除
    @DeleteMapping("/delUser")
    public Result delUser(@RequestBody IdDelParams idDelParams){
        return userService.delUser(idDelParams);
    }

}
