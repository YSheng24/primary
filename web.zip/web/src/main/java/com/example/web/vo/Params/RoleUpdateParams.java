package com.example.web.vo.Params;

import lombok.Data;

@Data
public class RoleUpdateParams {
    private Integer id;
    private String roleName;
    private String descriptionR;
}
