package com.example.web.service;

import com.example.web.entity.Permission;
import com.example.web.entity.Role;
import com.example.web.vo.Params.*;
import com.example.web.vo.Result;

import java.util.List;

public interface PermissionService {
    //查
    List<Permission> getPerAll();

    //增
    Result addPer(PerAddParams per);

    //修改
    Result updatePer(PerUpdateParams id);

    //删除
    Result delPer(IdDelParams id);
}
