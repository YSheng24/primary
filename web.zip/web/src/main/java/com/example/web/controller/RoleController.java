package com.example.web.controller;

import com.example.web.entity.Role;
import com.example.web.service.RoleService;
import com.example.web.service.UserService;
import com.example.web.vo.Params.*;
import com.example.web.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    //查
    @GetMapping("/getRoleAll")
    public List<Role> getRoleAll(){
        List<Role> all = roleService.getRoleAll();
        return all;
    }
    //增
    @PostMapping("/addRole")
    public Result addRole(@RequestBody RoleAddParams role){
        return roleService.addRole(role);
    }
    //修改
    @PutMapping("/updateRole")
    public Result updateRole(@RequestBody RoleUpdateParams updateParams){
        return roleService.updateRole(updateParams);
    }
    //删除
    @DeleteMapping("/delRole")
    public Result delUser(@RequestBody IdDelParams idDelParams){
        return roleService.delRole(idDelParams);
    }

}
