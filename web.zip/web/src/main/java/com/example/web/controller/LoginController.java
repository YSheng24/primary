package com.example.web.controller;

import com.example.web.entity.User;
import com.example.web.service.LoginService;
import com.example.web.util.JWTUtils;
import com.example.web.vo.Params.LoginParams;
import com.example.web.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
public class LoginController {

    @Autowired
    private LoginService loginService;

    @GetMapping("/user/login")
    public Result login(@RequestBody LoginParams loginParam){
        return loginService.login(loginParam);
    }
}
